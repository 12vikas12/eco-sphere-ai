# EcoSphere – AI-Based Waste Detection and Recycling Recommendation System

## Project Overview

EcoSphere is a full-stack AI-powered application that detects waste types in images and provides:
- Multi-waste type detection with confidence percentages
- Recycling recommendations for each waste type
- Estimated recycling earnings (₹ value)
- Nearby recycling center finder
- Global statistics dashboard

---

## Project Structure

```
ecosphere-vscode/
├── backend/
│   ├── app.py               ← Flask API server
│   └── requirements.txt     ← Python dependencies
└── frontend/
    ├── index.html           ← Main detection page
    ├── centers.html         ← Recycling centers page
    ├── stats.html           ← Statistics dashboard
    ├── style.css            ← Pastel-themed styles
    └── app.js               ← Frontend logic
```

---

## Setup Instructions

### Step 1 – Backend Setup

Open Terminal in VS Code and navigate to the backend folder:

```bash
cd backend
```

Create a virtual environment (recommended):

```bash
python -m venv venv
```

Activate it:
- **Windows**: `venv\Scripts\activate`
- **Mac/Linux**: `source venv/bin/activate`

Install dependencies:

```bash
pip install -r requirements.txt
```

Start the server:

```bash
python app.py
```

The API will be available at: **http://localhost:5000**

---

### Step 2 – Frontend Setup

Open the `frontend/index.html` file directly in your browser, OR use VS Code's Live Server extension:

1. Install **"Live Server"** extension in VS Code
2. Right-click on `frontend/index.html`
3. Select **"Open with Live Server"**

The frontend will open at: **http://127.0.0.1:5500/frontend/index.html**

---

## API Endpoints

| Method | Endpoint                  | Description                          |
|--------|---------------------------|--------------------------------------|
| GET    | `/api/healthz`            | Health check                         |
| POST   | `/api/predict`            | Detect waste types in an image       |
| GET    | `/api/recycling-centers`  | Get all recycling centers            |
| GET    | `/api/waste-stats`        | Get global detection statistics      |

### POST /api/predict

**Request Body:**
```json
{
  "imageBase64": "base64_encoded_image_data",
  "filename": "photo.jpg"
}
```

**Response:**
```json
{
  "detections": [
    { "type": "Plastic", "confidence": 0.60, "color": "#B8D4F5", "icon": "bottle", "pricePerKg": 10 },
    { "type": "Metal", "confidence": 0.25, "color": "#D4C5F5", "icon": "wrench", "pricePerKg": 25 }
  ],
  "recommendation": "Plastic (60%): Clean and sort...\n\nMetal (25%): Separate ferrous...",
  "recyclingCenters": [...],
  "estimatedEarning": "₹18",
  "estimatedEarningValue": 18.0,
  "totalDetected": 2,
  "analysisTime": 0.01,
  "boundingBoxImage": "data:image/jpeg;base64,..."
}
```

---

## Recycling Price Guide

| Waste Type | Price/kg |
|------------|----------|
| E-Waste    | ₹50      |
| Metal      | ₹25      |
| Textile    | ₹12      |
| Plastic    | ₹10      |
| Paper      | ₹8       |
| Rubber     | ₹7       |
| Cardboard  | ₹6       |
| Glass      | ₹5       |
| Wood       | ₹4       |
| Organic    | ₹3       |

---

## Recycling Centers

The system includes 10 predefined recycling centers across India:
- GreenEarth Recycling Hub – Mumbai
- EcoRevive Center – Delhi
- ScrapMasters Ltd – Bangalore
- TechWaste Solutions – Hyderabad
- PaperPulp Recyclers – Chennai
- GlassCycle India – Pune
- Organic Composting Hub – Ahmedabad
- TextileRenew Initiative – Surat
- MetalWorld Scrapyard – Kolkata
- CleanCity Recycling Co. – Jaipur

---

## Features

- **Drag & Drop Upload** — Upload images easily
- **Multi-waste Detection** — Detects up to 3 waste types in one image
- **Confidence Scores** — Shows percentage confidence for each detected type
- **Earnings Calculator** — Calculates ₹ value of recyclable waste
- **Smart Center Matching** — Shows only centers that accept detected waste types
- **Statistics Dashboard** — Pie chart and bar chart with Recharts
- **Pastel Design** — Soft mint, lavender, peach color palette
- **Smooth Animations** — Fade-in effects, progress animations, card transitions

---

## Academic Presentation Notes

This project demonstrates:
1. **AI-based classification** – Multi-label waste type detection with confidence scoring
2. **Computer Vision concepts** – Image analysis and waste categorization
3. **RESTful API design** – Clean endpoint structure with proper HTTP methods
4. **Real-world usability** – Practical recycling guidance and earnings estimation
5. **Full-stack development** – Python Flask backend + HTML/CSS/JS frontend

---

## Troubleshooting

**"Could not connect to server"** — Make sure `python app.py` is running in the backend folder

**Images not loading** — Check browser console; make sure image files are valid JPG/PNG

**CORS errors** — The backend includes flask-cors; if you see CORS errors, restart the backend

---

*Built for academic presentation and demonstration purposes.*
